﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp.Models;

namespace WindowsFormsApp
{
    public partial class UserDashboard : Form
    {
        private Form _login;
        private User _user;
        private P111Entities db;

        public UserDashboard(Form login, User user)
        {
            InitializeComponent();
            _login = login;
            _user = user;
            db = new P111Entities();
        }

        private void UserDashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            _login.Close();
        }

        private void UserDashboard_Load(object sender, EventArgs e)
        {
            _login.Hide();

            dgvBooks.DataSource = db.Books.Select(b => new
            {
                b.Id,
                BookName=b.Name,
                Price=b.Price+" Azn",
                b.Count
            }).ToList();

            cmbBooks.Items.AddRange(db.Books.Select(b=>new CMBClass {
                Id=b.Id,
                Name=b.Name,
                Price=b.Price,
                Count=b.Count
            }).ToArray());
        }

        private void cmbBooks_SelectedValueChanged(object sender, EventArgs e)
        {
            int Id = (cmbBooks.SelectedItem as CMBClass).Id;
            DgvRefreshOneData(Id);
        }

        private void DgvRefreshOneData(int Id)
        {
            dgvBooks.DataSource = null;
            dgvBooks.DataSource = db.Books.Where(b => b.Id == Id).Select(b => new
            {
                b.Id,
                BookName = b.Name,
                Price = b.Price + " Azn",
                b.Count
            }).ToList();
        }

        private void btnAddSale_Click(object sender, EventArgs e)
        {
            CMBClass selectedBook = (cmbBooks.SelectedItem as CMBClass);
            int count=(int)nBookNumber.Value;

            if (selectedBook.Count < count)
            {
                MessageBox.Show("Books count not enough", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            ListClass lc = new ListClass()
            {
                Id = selectedBook.Id,
                Name = selectedBook.Name,
                Price = selectedBook.Price,
                Count = count
            };

            lbCellBooks.Items.Add(lc);

            decimal total = decimal.Parse(lblTotal.Text);
            lblTotal.Text = (total + (selectedBook.Price*count)).ToString();


            //dgvBooks.DataSource = null;
            //dgvBooks.DataSource = db.Books.Where(b => b.Id == selectedBook.Id).Select(b => new
            //{
            //    b.Id,
            //    BookName = b.Name,
            //    Price = b.Price + " Azn",
            //    Count=b.Count-count
            //}).ToList();

            //cmbBooks.Items.Clear();
            //cmbBooks.Items.AddRange(db.Books.Select(b => new CMBClass
            //{
            //    Id = b.Id,
            //    Name = b.Name,
            //    Price = b.Price,
            //    Count = b.Count-count
            //}).ToArray());
        }
    }
}
